var hours = 1; // Reset when storage is more than 24hours
var now = new Date().getTime();
var setupTime = localStorage.getItem('expTime');
if (setupTime == null) {
    localStorage.setItem('setupTime', now)
} else {
    if(now-setupTime > hours*60*60*1000) {
        localStorage.clear();
    }
}