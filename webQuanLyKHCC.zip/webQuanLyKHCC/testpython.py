check_login=0

while(check_login!=1):
	pwd=getpass.getpass("")
	for line in f:
	    if line.lower() == hash_object:
	        check_login=1
	        break
	if(check_login!=1):
		print("Mật khẩu chưa đúng!")
	             	
print("Welcome to scanner !!!")
print("1 : Check attendance\n2 : Xóa\n3 : Hoàn tất điểm danh\n4$")
number = input("Choose the option:  ")
if number == "1":
    diem_danh()
elif number == "2":
    print("abhs")
elif number == "3":
    print("hghfdh")
elif number == "4":
    print("hfsfa") 
 else:
    print("Incorrect!!!")